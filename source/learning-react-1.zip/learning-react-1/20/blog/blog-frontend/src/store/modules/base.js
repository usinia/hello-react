import { createAction, handleActions } from 'redux-actions';

import { Map } from 'immutable';
import { pender } from 'redux-pender';

// action types

// action creators

// initial state
const initialState = Map({});

// reducer
export default handleActions({

}, initialState);
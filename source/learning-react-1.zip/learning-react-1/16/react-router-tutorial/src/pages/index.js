/* 다음 코드는 컴포넌트를 불러온 다음에
   동일한 이름으로 내보내 줍니다. */
export { default as Home } from './Home';
export { default as About } from './About';
export { default as Post } from './Post';
export { default as Posts } from './Posts';
   
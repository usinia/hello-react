import React from 'react';

const SplitMe = () => {
  return (
    <h3>
      청크
    </h3>
  );
};

export default SplitMe;

import React, { Component } from 'react';
import Hello from './Hello';

class App extends Component {
  render() {
    return (
      <Hello />
    );
  }
}

export default App;
import React, { Component } from 'react';
import EventPractice from './EventPractice';

class App extends Component {
  render() {
    return (
      <EventPractice/>
    );
  }
}

export default App;

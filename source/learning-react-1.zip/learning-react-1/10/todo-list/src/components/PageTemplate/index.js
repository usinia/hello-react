export { default } from './PageTemplate';
